VSTREAM 0.1.1 - Windows 10/11 (64-bit), VST3
Your DAW's audio on your phone, over your home network.

INSTALLATION
1. Copy the "VSTREAM.vst3" folder to:
     C:\Program Files\Common Files\VST3\
2. Reopen the DAW and rescan the plugins (in FL Studio: Options > Manage plugins >
   Find plugins). You find it among the effects: Zazzi > VSTREAM.
3. The first time, Windows Firewall asks whether the DAW may communicate on the network: tick
   "Private networks" and press Allow, otherwise the phone cannot reach it.

HOW TO USE IT
1. Put VSTREAM on the master (or on a bus, or on a track).
2. Phone and computer on the same Wi-Fi network.
3. Scan the plugin QR code with the phone camera: the page opens, tap play.
   No camera: type the address below the QR code in the phone browser (e.g. 192.168.1.23:7171).
Several phones can listen at once. The plugin uses port 7171 (if it is taken, the first free one
up to 7180).

ACTIVATION (licence)
The first time it opens, VSTREAM shows the LICENCE card: until it is active, the audio passes through
the DAW untouched but does not reach the phones. Paste the licence code you received (or drop the
.lic file on the card, or "Choose the .lic file") and press ACTIVATE. Internet is needed the first
time only. One code works on 3 computers. "Licence", bottom right, opens the card again.

The interface uses Microsoft Edge WebView2, already on up-to-date Windows 10 and 11. If the plugin
opens without its interface, install "WebView2 Runtime" from Microsoft's website.
