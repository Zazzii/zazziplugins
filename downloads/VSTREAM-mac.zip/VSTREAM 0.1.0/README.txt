VSTREAM 0.1.0 — macOS (Apple Silicon and Intel), macOS 11 or later
Your DAW's audio on your phone, over your home network.

INSTALLATION
0. If you had the version called "Zazzi STREAM", first delete "Zazzi STREAM.component" and
   "Zazzi STREAM.vst3" from the folders below: it is the same plugin under its old name.
1. Copy "VSTREAM.component" to:
     ~/Library/Audio/Plug-Ins/Components/
   (in the Finder: Go > Go to Folder…, paste the path)
   For VST3 DAWs, copy "VSTREAM.vst3" to:
     ~/Library/Audio/Plug-Ins/VST3/

2. The plugin is not signed by Apple yet: the first time, macOS blocks it.
   Open Terminal and paste these two lines:
     xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/"VSTREAM.component"
     xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/"VSTREAM.vst3"

3. Reopen the DAW. In Logic, if it does not show up: Logic Pro > Settings > Plug-in Manager >
   "Reset & Rescan Selection". You find it among the effects: Zazzi > VSTREAM.
   The first time, macOS asks whether the DAW may find devices on the local network: answer Allow,
   otherwise the phone cannot reach it.

HOW TO USE IT
1. Put VSTREAM on the master (or on a bus, or on a track).
2. Phone and computer on the same Wi-Fi network.
3. Scan the plugin QR code with the phone camera: the page opens, tap play.
   No camera: type the address below the QR code in the phone browser (e.g. 192.168.1.23:7171).
Several phones can listen at once. The plugin uses port 7171 (if it is taken, the first free one
up to 7180).

ACTIVATION (licence)
The first time it opens, VSTREAM shows the LICENCE card: until it is active, the audio passes through
the DAW untouched but does not reach the phones. Paste the licence code you received (or drop the
.lic file on the card, or "Choose the .lic file") and press ACTIVATE. Internet is needed the first
time only. One code works on 3 computers. "Licence", bottom right, opens the card again.
